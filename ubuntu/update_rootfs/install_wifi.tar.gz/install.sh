#!/bin/sh

cp -a * /

