# Instructions for Installing Ubuntu Filesystem on Minized eMMC 

#Prepare USB Stick with the following conditions
# 1) USB fully formatted for EXT4.  Use tools like MiniTool Partition Wizard on Windows PC
# 2) USB files in the following directory structure.  Use tools like Ext2Fsd for copying files on Windows PC
#    /
#	 prepare_emmc.sh (this script)
#    --/boot (provided)
#           -- image.ub
#			-- wpa_supplicant.conf
# 			
#    --/ext4 (provided)
#           -- /lib
#				-- (ext4 libs)
#			-- mkfs.ext4
#	 --/rootfs (download from https://rcn-ee.com/rootfs/eewiki/minfs/) 
#			-- armhf-rootfs-ubuntu-xenial.tar

#Boot Minized with built-in image and mount the usb to /mnt/usb/boot/image and run this script
#  mount /dev/sda1 /mnt/usb

# ******Start of Script ****** 

#in case the eMMC  auto-mounted, unmount them first
#For 2016.4 BSPs
umount /run/media/mmcblk1p1
#For 2017.1 and newer BSPs
umount /mnt/emmc
#Delete eMMC partition (if it exists) and add two partitions:
#partition 1: 128MB for boot
#partition 2: Rest of device for rootfs
echo "fdisk /dev/mmcblk1 (1 partition of 128MB)"
echo -e "d
n
p
1
1
+128M
a
1
n
p
2
3908
232448
p
w
" | fdisk /dev/mmcblk1

echo "sleep 1"
sleep 1

#Format eMMC partition #1 as a DOS partition
echo "mkdosfs -F 32 /dev/mmcblk1p1"
mkdosfs -F 32 -n boot /dev/mmcblk1p1

echo "sleep 1"
sleep 1

#Format eMMC partition #2 as an EXT4 partition
echo "mkfs.ext4 -L root /dev/mmcblk1p2"
export LD_LIBRARY_PATH=/mnt/usb/ext4/lib
/mnt/usb/ext4/mkfs.ext4 -L root /dev/mmcblk1p2

#Mount eMMC boot and root drives
echo "/dev/mmcblk1p1 /mnt/emmc"
mkdir /mnt/emmc
mount /dev/mmcblk1p1 /mnt/emmc
echo "/dev/mmcblk1p2 /mnt/root"
mkdir /mnt/root
mount /dev/mmcblk1p2 /mnt/root

#Copy boot files from USB to eMMC boot partition = /dev/mmcblk1p1 (remember to apply auxiliary power!)
echo "cp /mnt/usb/boot/* /mnt/emmc"
cp /mnt/usb/boot/* /mnt/emmc

echo "ls -l /mnt/emmc"
ls -l /mnt/emmc

#To prevent file corruption:
echo "sync"
sync

#Uncompress Ubuntu rootfs onto eMMC root partition = /dev/mmcblk1p2 (remember to apply auxiliary power!)
echo "tar -xfp /mnt/usb/rootfs/armhf-rootfs-ubuntu-xenial.tar -C /mnt/root"
tar -xfp /mnt/usb/rootfs/armhf-rootfs-ubuntu-xenial.tar -C /mnt/root
echo "sync"
sync

#set root access permissions on rootfs
echo "chown root:root /mnt/root"
chown root:root /mnt/root
echo "chmod 755 /mnt/root/"
chmod 755 /mnt/root/


#Unmount eMMC:
echo "umount /mnt/emmc"
umount /mnt/emmc
umount /mnt/root

echo "MiniZed Factory Restore is now complete"
echo "Issue command reboot now"

